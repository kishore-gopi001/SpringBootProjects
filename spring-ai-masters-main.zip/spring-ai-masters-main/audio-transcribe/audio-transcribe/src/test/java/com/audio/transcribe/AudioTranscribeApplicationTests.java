package com.audio.transcribe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudioTranscribeApplicationTests {

	@Test
	void contextLoads() {
	}

}
